"""
Dataset implementation.
"""
import json
import torch
from torch.utils.data import Dataset, DataLoader
from typing import List, Dict, Any, Optional, Tuple
from tokenizer.simple_tokenizer import SimpleTokenizer
import random
from transformers import AutoTokenizer


class TextDataset(Dataset):
    """Text dataset."""

    def __init__(
        self,
        texts: List[str],
        tokenizer: AutoTokenizer,
        max_length: int = 512,
        pad_token_id: int = 0,
        bos_token_id: int = 1,
        eos_token_id: int = 2
    ):
        """
        Initialize.

        Args:
            texts: List of texts
            tokenizer: Tokenizer
            max_length: Maximum sequence length
            pad_token_id: Padding token ID
            bos_token_id: Beginning of sequence token ID
            eos_token_id: End of sequence token ID
        """
        self.texts = texts
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.pad_token_id = pad_token_id
        self.bos_token_id = bos_token_id
        self.eos_token_id = eos_token_id

    def __len__(self) -> int:
        """Return dataset size."""
        return len(self.texts)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        """
        Get item.

        Args:
            idx: Item index

        Returns:
            Dictionary with input and target tokens
        """
        text = self.texts[idx]
        
        encodings = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        input_ids = encodings['input_ids'].squeeze()
        attention_mask = encodings['attention_mask'].squeeze()
        
        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask
        }


def create_dataloader(
    texts: List[str],
    tokenizer: AutoTokenizer,
    max_seq_len: int = 512,
    batch_size: int = 32,
    shuffle: bool = True,
    num_workers: int = 4,
    pad_token_id: int = 0,
    bos_token_id: int = 1,
    eos_token_id: int = 2
) -> DataLoader:
    """
    Create data loader.

    Args:
        texts: List of texts
        tokenizer: Tokenizer
        max_seq_len: Maximum sequence length
        batch_size: Batch size
        shuffle: Shuffle data
        num_workers: Number of worker processes
        pad_token_id: Padding token ID
        bos_token_id: Beginning of sequence token ID
        eos_token_id: End of sequence token ID

    Returns:
        Data loader
    """
    dataset = TextDataset(
        texts=texts,
        tokenizer=tokenizer,
        max_length=max_seq_len,
        pad_token_id=pad_token_id,
        bos_token_id=bos_token_id,
        eos_token_id=eos_token_id
    )

    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True
    )


def load_jsonl_dataset(
    file_path: str,
    text_field: str = "text",
    max_samples: Optional[int] = None
) -> List[str]:
    """
    Завантаження датасету з JSONL файлу.
    
    Args:
        file_path: Шлях до файлу
        text_field: Назва поля з текстом
        max_samples: Максимальна кількість зразків
        
    Returns:
        Список текстів
    """
    texts = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            if max_samples and len(texts) >= max_samples:
                break
            data = json.loads(line)
            if text_field in data:
                texts.append(data[text_field])
    return texts


def split_dataset(
    texts: List[str],
    train_ratio: float = 0.8,
    val_ratio: float = 0.1,
    test_ratio: float = 0.1,
    seed: int = 42
) -> tuple:
    """
    Розділення датасету на тренувальний, валідаційний та тестовий.
    
    Args:
        texts: Список текстів
        train_ratio: Частка тренувального набору
        val_ratio: Частка валідаційного набору
        test_ratio: Частка тестового набору
        seed: Seed для відтворюваності
        
    Returns:
        Кортеж (train_texts, val_texts, test_texts)
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6
    
    random.seed(seed)
    random.shuffle(texts)
    
    n = len(texts)
    train_size = int(n * train_ratio)
    val_size = int(n * val_ratio)
    
    train_texts = texts[:train_size]
    val_texts = texts[train_size:train_size + val_size]
    test_texts = texts[train_size + val_size:]
    
    return train_texts, val_texts, test_texts


def collate_fn(batch: List[Dict[str, torch.Tensor]]) -> Dict[str, torch.Tensor]:
    """
    Batch collation function.

    Args:
        batch: List of items

    Returns:
        Dictionary with batch tensors
    """
    input_ids = torch.stack([item["input_ids"] for item in batch])
    attention_mask = torch.stack([item["attention_mask"] for item in batch])

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask
    } 